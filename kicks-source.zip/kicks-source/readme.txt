
Thanks for Downloading KICKS source code. The instructions for installing KICKS source code are available online at http://www.kicksfortso.com/User%27s%20Guide/Installation.shtml If the online instructions are not immediately available the instructions are also available in either the normal KICKS TSO or CMS downloads, which are prerequisites.


1. Accept the license terms and download the KICKS package (kicks-source.zip).

2. Unzip the package resulting in a single folder named kicks-source

  kicks-source.xmi - an XMIT file you will upload to your TSO system.

  kicks-license.txt - a text file of the license you agreed to when you downloaded the KICKS package.

  readme.txt - a text file with this information, and telling you to go to the normal KICKS User's Guide Installation section to continue the install.

Thanks for Downloading KICKS source code, enjoy...


