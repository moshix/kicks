
Thanks for Downloading KICKS. The instructions for installing KICKS are available online at http://www.kicksfortso.com/User%27s%20Guide/Installation.shtml If the online instructions are not immediately available the instructions are also available in this download, as below...


z/OS    -- or --    Turnkey MVS

1. Accept the license terms and download the KICKS package (kicks-tso-v1r5m0.zip).

2. Unzip the package resulting in a single folder named kicks-tso-v1r5m0

  kicks-tso-v1r5m0.xmi - an XMI file you will upload to your system.

  User's Guide - a folder containing the KICKS User's Guide.

  Read User's Guide.htm - an icon you can click to read the User's Guide. (It's really just an html redirect to the installation.shtml file inside the User's Guide folder).

  kicks-license.txt - a text file of the license you agreed to when you downloaded the KICKS package.

  readme.txt - a text file with this information, and telling you to go to the User's Guide Installation section to continue the install.

3. Click on the Read User's Guide icon, and continue installation as directed in the INSTALL section.



Thanks for Downloading KICKS, enjoy...


